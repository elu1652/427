The shellmemory.c has been configured a bit where char *mem_get_value(char *var_in) returns null instead of printing a string
my_mkdir returns bad command if the directory already exists. i was unsure if i should have handled it differently as it was not stated in the instructions
